"""Bot sederhana: memainkan game lewat hook IO (sama seperti UI Android)."""
import os, sys, random, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["ECHOES_DB"] = os.path.join(tempfile.mkdtemp(), "t.db")
import game_core as g

random.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 1)
log, state = [], {"auth": 0, "steps": 0}

def w_menu(options, prompt=""):
    state["steps"] += 1
    assert state["steps"] < 20000, "loop tanpa akhir"
    joined = " | ".join(options)
    if "Register" in joined:
        state["auth"] += 1
        return 1 if state["auth"] == 1 else 4
    if "Lanjutkan petualangan" in joined:
        return 2
    if "Warrior" in joined:
        return 1
    if "Serang" in joined:  # pertarungan
        return random.choice([1, 1, 1, 1, 2, 4])
    if "Lanjutkan cerita" in joined:  # hub: grinding dulu, istirahat, baru lanjut
        state["hub"] = state.get("hub", 0) + 1
        if state["hub"] % 40 == 0:
            return 1
        return 4 if state["hub"] % 5 == 0 else 2
    if "Yakin" in prompt:
        return 2
    if "Bangkit dan coba lagi" in joined:
        state["retry"] = state.get("retry", 0) + 1
        return 1 if state["retry"] < 30 else 2
    if "Keluar toko" in joined:
        return len(options)
    if "Batal" in joined[-6:]:
        return len(options)
    return random.randint(1, len(options))

g.IO.update(print=lambda t: log.append(t), input=lambda p="": "hero" if "Username" in p or "nama" in p else "pw123",
            menu=w_menu, pause=lambda: None)
g.run_game()
text = "\n".join(log)
print("langkah:", state["steps"], "| baris log:", len(log))
print("tamat:", "Terima kasih telah bermain" in text, "| game over:", text.count("GAME OVER"))
