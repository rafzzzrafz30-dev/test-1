# echoes_of_the_forgotten_crown.py
# ==========================================================
#  ECHOES OF THE FORGOTTEN CROWN
#  RPG teks dengan akun, save game, 4 chapter dan 4 bos.
# ==========================================================
import hashlib
import hmac
import json
import os
import random
import sqlite3
import builtins

# ----------------------------------------------------------
# Hook I/O: di versi Android, UI Kivy memasang fungsi di IO.
# Tanpa hook, game tetap berjalan di terminal seperti aslinya.
# ----------------------------------------------------------
_builtin_print = builtins.print
_builtin_input = builtins.input
IO = {"print": None, "input": None, "menu": None, "pause": None}


def print(*args, sep=" ", end="\n", **kwargs):
    if IO["print"]:
        IO["print"](sep.join(str(a) for a in args))
    else:
        _builtin_print(*args, sep=sep, end=end, **kwargs)


def input(prompt=""):
    if IO["input"]:
        return IO["input"](prompt)
    return _builtin_input(prompt)


# ==========================================
# DATABASE
# ==========================================

DB_PATH = os.environ.get("ECHOES_DB", "database.db")

db = sqlite3.connect(DB_PATH, check_same_thread=False)
cursor = db.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
)
""")
cursor.execute("""
CREATE TABLE IF NOT EXISTS saves (
    user_id INTEGER PRIMARY KEY,
    data TEXT NOT NULL,
    updated TEXT DEFAULT CURRENT_TIMESTAMP
)
""")
db.commit()

CURRENT_USER_ID = None  # diisi setelah login / register


# ==========================================
# INPUT HELPER
# ==========================================

def ask(prompt):
    return input(prompt).strip()


def menu(options, prompt="Pilihan: "):
    """Tampilkan daftar pilihan, ulangi sampai valid. Mengembalikan angka 1..n."""
    if IO["menu"]:
        return IO["menu"](options, prompt)
    for i, text in enumerate(options, 1):
        print(f"{i}. {text}")
    while True:
        raw = ask(prompt)
        if raw.isdigit() and 1 <= int(raw) <= len(options):
            return int(raw)
        print(f"Pilihan tidak valid. Pilih 1 sampai {len(options)}.")


def pause():
    if IO["pause"]:
        IO["pause"]()
        return
    ask("\n[Tekan Enter untuk lanjut]")


def say(*lines):
    for line in lines:
        print(line)


def bar(current, maximum, width=20):
    filled = 0 if maximum <= 0 else int(width * max(0, current) / maximum)
    return "[" + "#" * filled + "." * (width - filled) + "]"


# ==========================================
# DATA GAME
# ==========================================

CLASSES = ("Warrior", "Mage", "Rogue")

CONSUMABLES = {
    "Potion Kesehatan": {"hp": 40, "mp": 0, "price": 25},
    "Potion Mana": {"hp": 0, "mp": 30, "price": 25},
    "Elixir Naga": {"hp": 100, "mp": 50, "price": 90},
}

# (nama, bonus serangan, harga, chapter minimal)
WEAPONS = {
    "Warrior": [("Pedang Besi", 4, 60, 0), ("Kapak Baja Aether", 8, 160, 1),
                ("Greatsword Frostpeak", 13, 320, 2), ("Bilah Cahaya Kerajaan", 18, 520, 3)],
    "Mage": [("Tongkat Ek", 4, 60, 0), ("Tongkat Kristal Hijau", 8, 160, 1),
             ("Tongkat Es Abadi", 13, 320, 2), ("Tongkat Bintang Kerajaan", 18, 520, 3)],
    "Rogue": [("Belati Baja", 4, 60, 0), ("Belati Bisa Hutan", 8, 160, 1),
              ("Belati Embun Beku", 13, 320, 2), ("Belati Bayangan Kerajaan", 18, 520, 3)],
}

# (nama, pertahanan, harga, chapter minimal)
ARMORS = [
    ("Jubah Kulit", 2, 40, 0),
    ("Baju Rantai", 4, 120, 1),
    ("Zirah Dwarf", 7, 260, 2),
    ("Zirah Kerajaan", 10, 450, 3),
]

# Skill per kelas: stat dasar x pengali, jumlah hit, biaya mana, level minimal
SKILLS = {
    "Warrior": [
        {"name": "Tebasan Perkasa", "cost": 15, "level": 1, "stat": "strength", "mult": 2.0, "hits": 1,
         "text": "Kamu menebas dengan seluruh tenagamu"},
        {"name": "Amukan Titan", "cost": 30, "level": 5, "stat": "strength", "mult": 3.6, "hits": 1,
         "text": "Tanah bergetar saat kamu menghantam musuh dengan amukan titan"},
    ],
    "Mage": [
        {"name": "Bola Api", "cost": 15, "level": 1, "stat": "intelligence", "mult": 2.0, "hits": 1,
         "text": "Bola api meledak di tubuh musuh"},
        {"name": "Badai Arkana", "cost": 30, "level": 5, "stat": "intelligence", "mult": 3.6, "hits": 1,
         "text": "Badai arkana berputar dan mengoyak musuh"},
    ],
    "Rogue": [
        {"name": "Tusukan Bayangan", "cost": 15, "level": 1, "stat": "agility", "mult": 2.0, "hits": 1,
         "text": "Kamu menghilang lalu menusuk dari bayangan"},
        {"name": "Seribu Pisau", "cost": 30, "level": 5, "stat": "agility", "mult": 1.3, "hits": 3,
         "text": "Hujan pisau menyerbu musuh"},
    ],
}

locations = {
    "Desa Aetherwood": {
        "desc": "Desa kecil yang damai di pinggir hutan. Penduduk takut karena serangan makhluk gelap.",
        "npcs": ["Elder Thorne", "Lira the Innkeeper"]
    },
    "Hutan Eldergloom": {
        "desc": "Hutan gelap penuh rahasia kuno. Konon ada kuil terlupakan di dalamnya.",
        "npcs": ["Mysterious Druid"]
    },
    "Gunung Frostpeak": {
        "desc": "Pegunungan dingin tempat para dwarf hidup. Ada rumor tentang artefak kuno.",
        "npcs": ["King Dwarf Thrain"]
    },
    "Istana Eldoria": {
        "desc": "Ibu kota kerajaan. Raja tampaknya menyembunyikan sesuatu yang besar.",
        "npcs": ["Raja Arion", "Penasihat Gelap"]
    }
}

SHOPKEEPERS = {
    "Desa Aetherwood": "Lira, pemilik penginapan",
    "Hutan Eldergloom": "Pedagang Pengembara",
    "Gunung Frostpeak": "Pandai Besi Dwarf",
    "Istana Eldoria": "Pedagang Istana",
}

REST_COST = {"Desa Aetherwood": 5, "Hutan Eldergloom": 10, "Gunung Frostpeak": 10, "Istana Eldoria": 15}

# Level yang disarankan tiap chapter (dipakai untuk membatasi grinding)
RECOMMENDED_LEVEL = {0: 1, 1: 3, 2: 5, 3: 7}

# Musuh acak: (nama, hp, atk, gold, exp)
ENCOUNTERS = {
    "Desa Aetherwood": [("Serigala Liar", 32, 8, 10, 24), ("Goblin Pencuri", 28, 9, 14, 22),
                        ("Kelelawar Bayangan", 24, 10, 12, 22)],
    "Hutan Eldergloom": [("Laba-laba Racun", 55, 12, 20, 40), ("Roh Hutan", 62, 13, 22, 44),
                         ("Treant Muda", 75, 12, 24, 46)],
    "Gunung Frostpeak": [("Serigala Es", 85, 16, 30, 60), ("Golem Salju", 115, 17, 36, 68),
                         ("Harpy Beku", 80, 19, 32, 62)],
    "Istana Eldoria": [("Prajurit Terkorupsi", 120, 21, 42, 85), ("Penyihir Bayangan", 100, 25, 46, 90),
                       ("Gargoyle Batu", 140, 22, 44, 92)],
}

NPC_LINES = {
    "Elder Thorne": [
        "'Seratus tahun lalu, Mahkota Eldoria menyegel Kehampaan. Kini segelnya retak.'",
        "'Musuh besar sering memberi tanda sebelum menyerang. Bacalah dan bertahanlah!'",
    ],
    "Lira the Innkeeper": [
        "'Istirahatlah di penginapanku. Murah, hangat, dan tidak ada serigala di kamar.'",
        "'Potion itu penyelamat. Jangan masuk ke pertarungan besar tanpa persediaan.'",
    ],
    "Mysterious Druid": [
        "'Hutan ini sakit. Ada sesuatu yang menetes dari kuil, hitam seperti tinta.'",
        "'Penjaga kuil dulu sahabat kami. Sekarang matanya kosong.'",
    ],
    "King Dwarf Thrain": [
        "'Kami para dwarf menempa baja, bukan menyerah pada naga!'",
        "'Naga es itu bangkit saat langit di utara menghitam. Itu bukan kebetulan.'",
    ],
    "Raja Arion": [
        "'...Aku... lelah. Siapa namamu, Nak? Wajahmu... mengingatkanku pada seseorang.'",
    ],
    "Penasihat Gelap": [
        "'Tuan Malachar sangat peduli pada rajaku. Dia tak pernah meninggalkan sisinya.' (kata seorang pelayan)",
    ],
}


# ==========================================
# PLAYER
# ==========================================

SAVE_FIELDS = (
    "level", "exp", "max_exp", "health", "max_health", "mana", "max_mana", "gold",
    "strength", "agility", "intelligence", "inventory", "weapon", "armor",
    "alignment", "location", "chapter", "fragments", "flags",
)


class Player:
    def __init__(self, name, char_class):
        self.name = name
        self.char_class = char_class
        self.level = 1
        self.exp = 0
        self.max_exp = 100
        self.health = 100
        self.max_health = 100
        self.mana = 50
        self.max_mana = 50
        self.gold = 50

        if char_class == "Warrior":
            self.strength, self.agility, self.intelligence = 15, 8, 7
        elif char_class == "Mage":
            self.strength, self.agility, self.intelligence = 7, 10, 18
        else:
            self.strength, self.agility, self.intelligence = 10, 18, 8

        self.inventory = {"Potion Kesehatan": 2, "Potion Mana": 1}
        self.weapon = ("Pisau Tua", 0)
        self.armor = ("Pakaian Lusuh", 0)
        self.alignment = 0
        self.location = "Desa Aetherwood"
        self.chapter = 0          # indeks chapter berikutnya yang dimainkan
        self.fragments = 0        # jumlah Crown Fragment
        self.flags = {}           # penanda pilihan cerita

    # ---------- save / load ----------
    def to_dict(self):
        data = {"name": self.name, "char_class": self.char_class}
        for key in SAVE_FIELDS:
            data[key] = getattr(self, key)
        return json.loads(json.dumps(data))

    @classmethod
    def from_dict(cls, data):
        if data["char_class"] not in CLASSES:
            raise ValueError("kelas tidak dikenal")
        player = cls(str(data["name"]), data["char_class"])
        for key in SAVE_FIELDS:
            setattr(player, key, data[key])
        player.weapon = (str(player.weapon[0]), int(player.weapon[1]))
        player.armor = (str(player.armor[0]), int(player.armor[1]))
        player.inventory = {str(k): int(v) for k, v in dict(player.inventory).items() if int(v) > 0}
        player.flags = dict(player.flags)
        for key in ("level", "exp", "max_exp", "health", "max_health", "mana", "max_mana",
                    "gold", "strength", "agility", "intelligence", "alignment", "chapter", "fragments"):
            setattr(player, key, int(getattr(player, key)))
        if player.location not in locations or player.level < 1 or player.max_exp < 1:
            raise ValueError("data save rusak")
        player.health = max(1, min(player.health, player.max_health))
        player.mana = max(0, min(player.mana, player.max_mana))
        return player

    def restore(self, snapshot):
        self.__dict__.update(Player.from_dict(snapshot).__dict__)

    # ---------- progres ----------
    def gain_exp(self, amount):
        self.exp += amount
        while self.exp >= self.max_exp:
            self.exp -= self.max_exp
            self.level_up()

    def level_up(self):
        self.level += 1
        self.max_health += 20
        self.health = self.max_health
        self.max_mana += 10
        self.mana = self.max_mana
        self.strength += 2
        self.agility += 2
        self.intelligence += 2
        self.max_exp = int(self.max_exp * 1.3)
        print(f"\n*** Level Up! Sekarang level {self.level}! HP & Mana pulih sepenuhnya. ***")
        for skill in SKILLS[self.char_class]:
            if skill["level"] == self.level:
                print(f"*** Skill baru terbuka: {skill['name']} (Mana {skill['cost']}) ***")

    def add_item(self, name, count=1):
        self.inventory[name] = self.inventory.get(name, 0) + count

    def shift_alignment(self, amount):
        self.alignment += amount

    # ---------- statistik tempur ----------
    @property
    def defense(self):
        return self.armor[1]

    def dodge_chance(self):
        return min(0.35, self.agility * 0.01)

    def crit_chance(self):
        bonus = 0.10 if self.char_class == "Rogue" else 0.0
        return min(0.5, 0.05 + self.agility * 0.004 + bonus)

    def available_skills(self):
        return [s for s in SKILLS[self.char_class] if s["level"] <= self.level]

    def basic_attack(self):
        damage = self.strength + self.weapon[1] + random.randint(-3, 5)
        crit = random.random() < self.crit_chance()
        if crit:
            damage = int(damage * 1.8)
        return max(1, damage), crit

    def skill_hits(self, skill):
        hits = []
        for _ in range(skill["hits"]):
            base = int(getattr(self, skill["stat"]) * skill["mult"]) + self.weapon[1] + random.randint(0, 5)
            crit = random.random() < self.crit_chance()
            if crit:
                base = int(base * 1.8)
            hits.append((max(1, base), crit))
        return hits

    def take_hit(self, raw, defending=False, can_dodge=True, guard_factor=0.5):
        """Terapkan serangan musuh. Mengembalikan damage yang diterima (0 jika dihindari)."""
        if can_dodge and random.random() < self.dodge_chance():
            return 0
        damage = raw - self.defense
        if defending:
            damage = int(damage * guard_factor)
        damage = max(1, damage)
        self.health = max(0, self.health - damage)
        return damage

    def show_status(self):
        alignment_text = (
            "Baik" if self.alignment > 30
            else "Jahat" if self.alignment < -30
            else "Netral"
        )
        print(f"\n=== {self.name} - {self.char_class} Lv.{self.level} ===")
        print(f"HP: {self.health}/{self.max_health} | Mana: {self.mana}/{self.max_mana}")
        print(f"STR: {self.strength} | AGI: {self.agility} | INT: {self.intelligence}")
        print(f"EXP: {self.exp}/{self.max_exp}")
        print(f"Gold: {self.gold} | Alignment: {alignment_text}")
        print(f"Senjata: {self.weapon[0]} (+{self.weapon[1]}) | Armor: {self.armor[0]} (+{self.armor[1]})")
        print(f"Crown Fragment: {self.fragments}/4")
        print(f"Lokasi: {self.location}")


# ==========================================
# ENEMY DAN BOSS
# ==========================================

class Enemy:
    def __init__(self, name, hp, atk, gold_reward, exp_reward, drops=None):
        self.name = name
        self.hp = hp
        self.max_hp = hp
        self.atk = atk
        self.gold_reward = gold_reward
        self.exp_reward = exp_reward
        self.drops = drops if drops is not None else [("Potion Kesehatan", 0.2)]
        self.is_boss = False
        self.charging = False

    def act(self, player, defending):
        raw = self.atk + random.randint(-2, 3)
        damage = player.take_hit(raw, defending)
        if damage == 0:
            print(f"{self.name} menyerang, tetapi kamu menghindar!")
        else:
            print(f"{self.name} menyerang! Kamu menerima {damage} damage.")
        return damage


class Boss(Enemy):
    """Bos dengan fase, serangan terkumpul (telegraph) dan drop pasti."""

    def __init__(self, name, hp, atk, gold, exp, charge_every, charge_text, heavy_name,
                 heavy_mult, phases, drops, intro=None):
        super().__init__(name, hp, atk, gold, exp, drops)
        self.is_boss = True
        self.charge_every = charge_every
        self.charge_text = charge_text
        self.heavy_name = heavy_name
        self.heavy_mult = heavy_mult
        self.phases = phases
        self.intro = intro or []
        self.phase = 0
        self.counter = 0
        self.lifesteal = 0.0

    def _check_phases(self):
        while self.phase < len(self.phases) and self.hp <= self.phases[self.phase]["hp"] * self.max_hp:
            ph = self.phases[self.phase]
            self.phase += 1
            print("\n" + ph["msg"])
            self.atk += ph.get("atk", 0)
            if "lifesteal" in ph:
                self.lifesteal = ph["lifesteal"]
            if "charge_every" in ph:
                self.charge_every = ph["charge_every"]
            if ph.get("heal"):
                healed = int(self.max_hp * ph["heal"])
                self.hp = min(self.max_hp, self.hp + healed)
                print(f"{self.name} memulihkan {healed} HP!")

    def act(self, player, defending):
        self._check_phases()
        if self.charging:
            self.charging = False
            raw = int(self.atk * self.heavy_mult) + random.randint(-2, 3)
            print(f"\n>>> {self.name} melepaskan {self.heavy_name}!")
            damage = player.take_hit(raw, defending, can_dodge=False, guard_factor=0.25)
            if defending:
                print(f"Kamu bertahan! Damage berkurang drastis menjadi {damage}.")
            else:
                print(f"Serangan telak! Kamu menerima {damage} damage.")
            return damage

        self.counter += 1
        if self.counter >= self.charge_every:
            self.counter = 0
            self.charging = True
            print(f"\n!! {self.name} {self.charge_text}")
            print("!! Gunakan Bertahan pada giliranmu berikutnya untuk menahan serangan besar!")
            return 0

        raw = self.atk + random.randint(-2, 3)
        damage = player.take_hit(raw, defending)
        if damage == 0:
            print(f"{self.name} menyerang, tetapi kamu menghindar!")
        else:
            print(f"{self.name} menyerang! Kamu menerima {damage} damage.")
            if self.lifesteal > 0 and self.hp > 0:
                steal = max(1, int(damage * self.lifesteal))
                self.hp = min(self.max_hp, self.hp + steal)
                print(f"{self.name} menyerap {steal} HP darimu!")
        return damage


# ==========================================
# ITEM
# ==========================================

def use_item(player, name):
    """Pakai consumable. Mengembalikan True bila item terpakai."""
    data = CONSUMABLES[name]
    gain_hp = min(player.max_health - player.health, data["hp"])
    gain_mp = min(player.max_mana - player.mana, data["mp"])
    if gain_hp <= 0 and gain_mp <= 0:
        print("HP dan Mana kamu sudah penuh. Item tidak dipakai.")
        return False
    player.health += gain_hp
    player.mana += gain_mp
    player.inventory[name] -= 1
    if player.inventory[name] <= 0:
        del player.inventory[name]
    parts = []
    if gain_hp:
        parts.append(f"HP +{gain_hp}")
    if gain_mp:
        parts.append(f"Mana +{gain_mp}")
    print(f"{name} digunakan! " + ", ".join(parts) + ".")
    return True


def item_menu(player):
    """Menu item (dipakai di pertarungan & luar pertarungan)."""
    names = [n for n in CONSUMABLES if player.inventory.get(n, 0) > 0]
    if not names:
        print("Kamu tidak punya item yang bisa dipakai!")
        return False
    options = [f"{n} x{player.inventory[n]}" for n in names] + ["Batal"]
    choice = menu(options, "Pakai item: ")
    if choice == len(options):
        return False
    return use_item(player, names[choice - 1])


# ==========================================
# COMBAT
# ==========================================

def show_battle(player, enemy):
    print(f"\n--- {player.name} Lv.{player.level} ---")
    print(f"HP   {bar(player.health, player.max_health)} {player.health}/{player.max_health}")
    print(f"Mana {bar(player.mana, player.max_mana)} {player.mana}/{player.max_mana}")
    print(f"--- {enemy.name} ---")
    print(f"HP   {bar(enemy.hp, enemy.max_hp)} {enemy.hp}/{enemy.max_hp}")
    if enemy.charging:
        print(f"!! {enemy.name} sedang mengumpulkan kekuatan! Pilih Bertahan!")


def do_attack(player, enemy):
    damage, crit = player.basic_attack()
    enemy.hp = max(0, enemy.hp - damage)
    print(f"{'CRITICAL! ' if crit else ''}Kamu memberikan {damage} damage!")


def do_skill(player, enemy):
    """Mengembalikan True jika giliran terpakai."""
    skills = player.available_skills()
    options = [f"{s['name']} (Mana {s['cost']})" for s in skills] + ["Batal"]
    choice = menu(options, "Pilih skill: ")
    if choice == len(options):
        return False
    skill = skills[choice - 1]
    if player.mana < skill["cost"]:
        print("Mana tidak cukup!")
        return False
    player.mana -= skill["cost"]
    print(f"{skill['text']}!")
    total = 0
    for damage, crit in player.skill_hits(skill):
        total += damage
        if skill["hits"] > 1:
            print(f"  {'CRITICAL! ' if crit else ''}Pisau mengenai: {damage} damage")
        elif crit:
            print("  CRITICAL!")
    enemy.hp = max(0, enemy.hp - total)
    print(f"{skill['name']} memberikan {total} damage!")
    return True


def combat(player, enemy, allow_flee=True):
    """Mengembalikan 'win', 'lose', atau 'fled'."""
    print(f"\n{'=' * 52}")
    if enemy.is_boss:
        print(f"  PERTARUNGAN BOS: {enemy.name}")
    else:
        print(f"  Pertarungan melawan {enemy.name} dimulai!")
    print("=" * 52)
    for line in getattr(enemy, "intro", []):
        print(line)

    while player.health > 0 and enemy.hp > 0:
        defending = False

        # --- giliran pemain (ulangi sampai ada aksi yang memakai giliran) ---
        while True:
            show_battle(player, enemy)
            options = ["Serang", "Skill", "Item", "Bertahan (kurangi damage, +mana)"]
            options.append("Lari" if allow_flee else "Lari (tidak bisa!)")
            action = menu(options, "Pilih aksi: ")

            if action == 1:
                do_attack(player, enemy)
                break
            if action == 2:
                if do_skill(player, enemy):
                    break
            elif action == 3:
                if item_menu(player):
                    break
            elif action == 4:
                defending = True
                player.mana = min(player.max_mana, player.mana + 6)
                print("Kamu mengambil posisi bertahan dan menarik napas (+6 Mana).")
                break
            elif action == 5:
                if not allow_flee:
                    print("Tidak ada jalan keluar dari pertarungan ini!")
                    continue
                if random.random() > 0.4:
                    print("Kamu berhasil melarikan diri!")
                    return "fled"
                print("Gagal melarikan diri!")
                break

        if enemy.hp <= 0:
            break

        # --- giliran musuh ---
        enemy.act(player, defending)
        if player.health <= 0:
            break
        player.mana = min(player.max_mana, player.mana + 2)

    if player.health <= 0:
        print(f"\nKamu dikalahkan oleh {enemy.name}...")
        return "lose"

    print(f"\nKamu menang melawan {enemy.name}!")
    player.gold += enemy.gold_reward
    print(f"+{enemy.gold_reward} Gold | +{enemy.exp_reward} EXP")
    for item, chance in enemy.drops:
        if random.random() < chance:
            player.add_item(item)
            print(f"Drop: {item}!")
    player.gain_exp(enemy.exp_reward)
    return "win"


# ==========================================
# DEFINISI BOS
# ==========================================

def make_verdanox():
    return Boss(
        "Verdanox, Penjaga Hutan yang Tercemar", hp=260, atk=17, gold=120, exp=260,
        charge_every=4, charge_text="menarik akar-akar raksasa dari dalam tanah...",
        heavy_name="Cengkeraman Akar Maut", heavy_mult=2.0,
        phases=[
            {"hp": 0.5, "atk": 4, "charge_every": 3,
             "msg": "Kulit kayu Verdanox retak, cairan hitam menyembur keluar! 'AKU... TIDAK... BISA... BERHENTI...'"},
        ],
        drops=[("Potion Kesehatan", 1.0), ("Potion Mana", 1.0)],
        intro=["Pohon purba setinggi menara bangkit dari altar. Matanya hanya lubang hitam.",
               "'Pergi... atau menjadi pupuk...'"],
    )


def make_vyrmax():
    return Boss(
        "Vyrmax, Naga Es Kuno", hp=430, atk=23, gold=200, exp=440,
        charge_every=4, charge_text="menghirup udara dalam-dalam, uap dingin mengepul dari rahangnya...",
        heavy_name="Nafas Badai Salju", heavy_mult=2.1,
        phases=[
            {"hp": 0.5, "atk": 4, "charge_every": 3,
             "msg": "Vyrmax mengepakkan sayap, badai salju mengamuk! 'KALIAN SEMUA AKAN MEMBEKU!'"},
        ],
        drops=[("Elixir Naga", 1.0), ("Potion Kesehatan", 1.0)],
        intro=["Bayangan raksasa menutupi langit. Sisik biru kristal berkilau di bawah bulan.",
               "'Serpihan itu... milikku. Berikan, manusia kecil.'"],
    )


def make_kael(enraged):
    return Boss(
        "Jenderal Kael, Pedang Raja", hp=520, atk=28, gold=260, exp=620,
        charge_every=4, charge_text="memasang kuda-kuda, pedangnya memancarkan cahaya putih...",
        heavy_name="Tebasan Pemutus Takdir", heavy_mult=2.0,
        phases=[
            {"hp": 0.5, "atk": 4, "charge_every": 3,
             "msg": "Kael mengusap darah di bibirnya. 'Aku bersumpah melindungi tahta ini... dengan nyawaku!'"},
        ],
        drops=[("Elixir Naga", 1.0), ("Potion Kesehatan", 1.0)],
        intro=["Jenderal Kael menghunus pedang. Zirah peraknya tak bernoda seratus pertempuran."] +
              (["'Kau berani menghina rajaku?! Aku akan menghabisimu!'"] if enraged else []),
    )


def make_malachar():
    return Boss(
        "Malachar, Herald Kehampaan", hp=760, atk=32, gold=0, exp=1000,
        charge_every=4, charge_text="mengangkat tangannya, kegelapan berputar di sekelilingnya...",
        heavy_name="Gerhana Jiwa", heavy_mult=2.0,
        phases=[
            {"hp": 0.66, "atk": 3, "lifesteal": 0.6, "charge_every": 3,
             "msg": "Kulit Malachar terkelupas. Dari baliknya muncul sosok hitam bermata ungu. "
                    "'INI... WUJUDKU YANG SEBENARNYA!' (Serangan biasanya kini menyerap HP-mu!)"},
            {"hp": 0.33, "atk": 3, "heal": 0.10, "charge_every": 2,
             "msg": "Retakan ruang terbuka di belakangnya. Kehampaan mengalir masuk. "
                    "'KEHAMPAAN TAK PERNAH MATI!'"},
        ],
        drops=[("Elixir Naga", 1.0)],
        intro=["Malachar melepas jubahnya. Udara di aula takhta membeku.",
               "'Seratus tahun aku menunggu. Kau hanya pengganggu terakhir.'"],
    )


# ==========================================
# HUB: TOKO, ISTIRAHAT, JELAJAH
# ==========================================

def shop(player):
    keeper = SHOPKEEPERS[player.location]
    print(f"\n=== TOKO: {keeper} ===")
    while True:
        offers = []  # (label, harga, jenis, data)
        for name, data in CONSUMABLES.items():
            offers.append((f"{name} (HP +{data['hp']}, Mana +{data['mp']})", data["price"], "item", name))
        for name, bonus, price, min_ch in WEAPONS[player.char_class]:
            if player.chapter >= min_ch and bonus > player.weapon[1]:
                offers.append((f"{name} [senjata, serangan +{bonus}]", price, "weapon", (name, bonus)))
        for name, defense, price, min_ch in ARMORS:
            if player.chapter >= min_ch and defense > player.armor[1]:
                offers.append((f"{name} [armor, pertahanan +{defense}]", price, "armor", (name, defense)))

        print(f"\nGold kamu: {player.gold}")
        options = [f"{label} - {price} Gold" for label, price, _, _ in offers] + ["Keluar toko"]
        choice = menu(options, "Beli: ")
        if choice == len(options):
            return
        label, price, kind, data = offers[choice - 1]
        if player.gold < price:
            print("Gold tidak cukup!")
            continue
        player.gold -= price
        if kind == "item":
            player.add_item(data)
        elif kind == "weapon":
            player.weapon = data
            print(f"Kamu memakai {data[0]}!")
        else:
            player.armor = data
            print(f"Kamu memakai {data[0]}!")
        print(f"Berhasil membeli {label.split(' [')[0].split(' (')[0]}.")


def rest(player):
    cost = REST_COST[player.location]
    if player.health >= player.max_health and player.mana >= player.max_mana:
        print("Kamu sudah segar bugar, tidak perlu istirahat.")
        return
    if player.gold < cost:
        print(f"Istirahat butuh {cost} Gold. Gold kamu tidak cukup.")
        return
    player.gold -= cost
    player.health = player.max_health
    player.mana = player.max_mana
    print(f"Kamu beristirahat (-{cost} Gold). HP dan Mana pulih sepenuhnya.")


def faint(player):
    """Kalah saat menjelajah: tidak game over, tapi ada hukuman."""
    lost = player.gold // 2
    player.gold -= lost
    player.health = max(1, player.max_health // 2)
    player.mana = player.max_mana // 2
    print(f"\nKamu pingsan... Seorang pengembara menyeretmu ke tempat aman. (-{lost} Gold)")


def explore(player):
    roll = random.random()
    if roll < 0.70:
        name, hp, atk, gold, exp = random.choice(ENCOUNTERS[player.location])
        rec = RECOMMENDED_LEVEL[player.chapter]
        if player.level >= rec + 4:
            exp = max(1, exp // 3)
            gold = gold // 2
        result = combat(player, Enemy(name, hp, atk, gold, exp))
        if result == "lose":
            faint(player)
    elif roll < 0.85:
        found = random.randint(10, 25) * (player.chapter + 1)
        player.gold += found
        print(f"\nKamu menemukan kantong tua berisi {found} Gold.")
    else:
        healed = player.max_health // 4
        player.health = min(player.max_health, player.health + healed)
        player.mana = min(player.max_mana, player.mana + player.max_mana // 4)
        print("\nKamu menemukan mata air jernih dan beristirahat sejenak. HP & Mana pulih sedikit.")


def talk(player):
    npcs = locations[player.location]["npcs"]
    options = npcs + ["Batal"]
    choice = menu(options, "Bicara dengan: ")
    if choice == len(options):
        return
    npc = npcs[choice - 1]
    print(f"\n{npc}: {random.choice(NPC_LINES[npc])}")


def save_game(player, quiet=False):
    if CURRENT_USER_ID is None:
        return
    try:
        cursor.execute(
            "INSERT OR REPLACE INTO saves (user_id, data) VALUES (?, ?)",
            (CURRENT_USER_ID, json.dumps(player.to_dict()))
        )
        db.commit()
        if not quiet:
            print("Permainan berhasil disimpan.")
    except sqlite3.Error as error:
        print(f"Gagal menyimpan: {error}")


def load_game():
    if CURRENT_USER_ID is None:
        return None
    cursor.execute("SELECT data FROM saves WHERE user_id = ?", (CURRENT_USER_ID,))
    row = cursor.fetchone()
    if not row:
        return None
    try:
        return Player.from_dict(json.loads(row[0]))
    except (ValueError, KeyError, TypeError, json.JSONDecodeError, IndexError):
        return None


def hub(player):
    """Persiapan sebelum cerita dilanjutkan. Keluar saat pemain memilih lanjut."""
    print(f"\n--- {player.location} ---")
    print(locations[player.location]["desc"])
    while True:
        print("\nApa yang akan kamu lakukan?")
        choice = menu([
            "Lanjutkan cerita",
            "Jelajahi sekitar (cari musuh / EXP / Gold)",
            "Toko",
            "Istirahat (pulihkan HP & Mana)",
            "Bicara dengan penduduk",
            "Status & Pakai item",
            "Simpan permainan",
        ], "Aksi: ")
        if choice == 1:
            if player.health < player.max_health * 0.5:
                print("HP kamu masih rendah. Yakin tetap lanjut?")
                if menu(["Ya, lanjut", "Tidak, kembali"], "Yakin: ") == 2:
                    continue
            return
        elif choice == 2:
            explore(player)
        elif choice == 3:
            shop(player)
        elif choice == 4:
            rest(player)
        elif choice == 5:
            talk(player)
        elif choice == 6:
            player.show_status()
            if player.inventory:
                print("\nInventaris:", ", ".join(f"{k} x{v}" for k, v in player.inventory.items()))
            item_menu(player)
        elif choice == 7:
            save_game(player)


# ==========================================
# CERITA: CHAPTER
# ==========================================

def story_fight(player, enemy):
    """Pertarungan cerita: tidak bisa lari. True bila menang."""
    return combat(player, enemy, allow_flee=False) == "win"


def chapter_1_intro(player):
    player.location = "Desa Aetherwood"
    print("\n" + "=" * 52)
    print("  CHAPTER 1: BAYANGAN DI DESA")
    print("=" * 52)


def chapter_1(player):
    say("\nKamu terbangun terengah-engah. Suara seorang wanita masih menggema di kepalamu:",
        "  'Anakku... temukan Mahkota... sebelum Kehampaan menelan segalanya...'",
        "\nDi luar, lonceng desa berdentang liar. Warga berlarian ke balai desa.",
        "Elder Thorne menghampirimu dengan wajah pucat.",
        "'Makhluk-makhluk gelap menyerang ternak kami. Pemimpinnya serigala raksasa bermata ungu.'")
    pause()

    print("\nApa yang kamu lakukan?")
    choice = menu(["Bantu warga melawan serigala", "Selidiki desa sendirian"])
    if choice == 1:
        say("\nKamu menghadang di gerbang desa. Seekor Serigala Alpha melompat dari kegelapan!")
        if not story_fight(player, Enemy("Serigala Alpha", 60, 12, 25, 40,
                                         drops=[("Potion Kesehatan", 1.0)])):
            return False
        player.shift_alignment(10)
        say("Warga bersorak dan memanggil namamu. Thorne menunduk hormat.")
    else:
        say("\nKamu menyelinap ke tepi desa dan menemukan jejak darah aneh...",
            "Jejak itu berakhir di sebuah rune hitam yang terukir di batu. Rune itu berdenyut seperti jantung.",
            "Serigala-serigala yang melihatmu mundur ke hutan, seakan takut pada sesuatu di belakangmu.")
        player.shift_alignment(-5)
        player.gain_exp(25)
        print("+25 EXP karena kehati-hatianmu.")
        player.add_item("Potion Kesehatan")
        print("Kamu menemukan Potion Kesehatan di dekat rune.")
    pause()

    say("\nMalam itu, mimpi itu datang lagi. Kakimu bergerak sendiri menuju kuil tua di bawah balai desa.",
        "Di atas altar yang berdebu, sebuah pecahan kristal melayang dan bercahaya.",
        "\nKamu menemukan Crown Fragment yang bercahaya!")
    player.fragments = max(player.fragments, 1)
    player.flags["fragment_1"] = True
    pause()

    say("\nSeorang pria berjubah mendekatimu dari bayang-bayang...",
        "  'Pecahan itu memilihmu. Aku sudah menunggu seumur hidup.'")
    print("\nApa yang kamu lakukan?")
    choice = menu(["Percaya padanya dan ikuti ke hutan",
                   "Serang dia karena curiga",
                   "Tanya tentang mimpi sang ratu"])

    if choice == 1:
        player.flags["orin"] = 2
        say("\n'Namaku Orin. Dahulu aku pengawal Ratu Seraphine. Percayamu akan kubalas.'")
    elif choice == 2:
        say("\nKamu menerjang! Pria itu menghunus belati dan menghilang di antara bayangan...")
        if not story_fight(player, Enemy("Orin, Penjaga Bayangan", 80, 18, 60, 70,
                                         drops=[("Potion Kesehatan", 1.0)])):
            return False
        player.shift_alignment(-20)
        player.flags["orin"] = 0
        say("\nOrin terduduk memegang bahunya, tersenyum pahit.",
            "'Reflek yang bagus... Seharusnya begitulah pewaris Mahkota. Aku Orin, pengawal Ratu Seraphine.'")
    else:
        player.flags["orin"] = 1
        player.shift_alignment(5)
        say("\nDia berkata: 'Ratu itu adalah ibumu... dan dia terperangkap di dunia lain.'",
            "'Seratus tahun lalu ia menyegel Kehampaan memakai Mahkota Eldoria. Mahkota itu pecah menjadi empat,",
            " dan penasihat raja, Malachar, mengumpulkannya agar segel itu bisa dibuka.'")
    pause()

    say("\n'Satu pecahan ada padamu. Tiga lainnya tersebar:",
        "  di kuil terlupakan Hutan Eldergloom, di sarang naga Gunung Frostpeak,",
        "  dan di Istana Eldoria, di tangan Malachar.'",
        "\nOrin menatap bulan. 'Kita berangkat ke hutan saat fajar.'")
    return True


def chapter_2_intro(player):
    player.location = "Hutan Eldergloom"
    print("\n" + "=" * 52)
    print("  CHAPTER 2: BISIKAN ELDERGLOOM")
    print("=" * 52)
    print("Kamu dan Orin masuk ke Hutan Eldergloom. Pohon-pohonnya berbisik menyebut namamu.")


def chapter_2(player):
    say("\nDi tengah hutan, seorang druid tua berlutut di samping seekor rusa roh yang terluka parah.",
        "'Tolong... luka ini berasal dari getah hitam kuil. Hanya obat yang bisa menyelamatkannya.'")
    print("\nApa yang kamu lakukan?")
    choice = menu(["Berikan Potion Kesehatan untuk rusa itu",
                   "Paksa druid memberi tahu jalan ke kuil",
                   "Abaikan dan lanjutkan perjalanan"])

    if choice == 1:
        if player.inventory.get("Potion Kesehatan", 0) > 0:
            player.inventory["Potion Kesehatan"] -= 1
            if player.inventory["Potion Kesehatan"] <= 0:
                del player.inventory["Potion Kesehatan"]
            player.shift_alignment(8)
            player.add_item("Potion Kesehatan", 2)
            player.add_item("Potion Mana", 1)
            say("\nRusa roh itu bangkit dan menyentuh keningmu dengan tanduknya. Cahaya hijau menyelimutimu.",
                "'Penjaga kuil dulu sahabat kami. Ia disiksa oleh getah hitam. Selamatkan dia jika kau mampu.'",
                "Druid memberimu 2 Potion Kesehatan dan 1 Potion Mana sebagai tanda terima kasih.")
            player.flags["druid_helped"] = True
        else:
            say("\nKamu tidak punya Potion Kesehatan untuk diberikan. Druid menunduk kecewa,",
                "tapi tetap menunjukkan jalan menuju kuil.")
    elif choice == 2:
        player.shift_alignment(-8)
        say("\nDruid gemetar dan menunjuk ke utara. Rusa roh itu mengembuskan napas terakhir.",
            "Orin menatapmu tanpa berkata apa-apa.")
    else:
        say("\nKamu berjalan melewati mereka. Suara rintihan rusa itu mengikutimu cukup lama.")
    pause()

    say("\nKuil Terlupakan berdiri di tengah kabut. Dinding batunya meneteskan getah hitam yang sama",
        "dengan yang kamu lihat pada rune di desa. Di tengah altar, pecahan kedua Mahkota berdenyut.",
        "\nSaat kamu melangkah masuk, tanah bergetar...")
    pause()

    if not story_fight(player, make_verdanox()):
        return False

    say("\nVerdanox jatuh berlutut. Getah hitam menguap dari tubuhnya. Matanya kembali berwarna hijau.",
        "'Anak... Seraphine? Bukan... kau lebih muda. Apakah aku... sudah bebas?'")
    print("\nApa yang kamu lakukan?")
    choice = menu(["Sucikan dia dengan Crown Fragment", "Akhiri penderitaannya"])
    if choice == 1:
        player.shift_alignment(10)
        player.add_item("Elixir Naga")
        player.add_item("Potion Kesehatan", 2)
        player.flags["verdanox_saved"] = True
        say("\nPecahan di tanganmu memancarkan cahaya hangat. Verdanox menutup mata dan tersenyum.",
            "'Terima kasih. Hutan akan mengingatmu.' Ia menyerahkan Elixir Naga dan beberapa ramuan hutan.")
    else:
        player.shift_alignment(-10)
        player.gold += 60
        say("\nKamu menebas sekali lagi. Verdanox runtuh menjadi abu dan daun kering.",
            "Di antara abunya, kamu menemukan 60 Gold dan sebuah pecahan kristal.")
    pause()

    say("\nCrown Fragment kedua kamu dapatkan!")
    player.fragments = max(player.fragments, 2)
    player.flags["fragment_2"] = True
    say("Orin memeriksa sisa getah di kayu. 'Lihat cap ini. Ini segel Kehampaan, ditanam oleh Malachar.'",
        "'Ia sudah menggerakkan pasukannya lebih dahulu dari kita. Dwarf di Frostpeak pasti dalam bahaya.'")
    return True


def chapter_3_intro(player):
    player.location = "Gunung Frostpeak"
    print("\n" + "=" * 52)
    print("  CHAPTER 3: PUNCAK YANG MEMBEKU")
    print("=" * 52)
    print("Angin dingin menusuk tulang saat kamu mendaki jalur sempit menuju Frostpeak.")


def chapter_3(player):
    say("\nGerbang benteng dwarf tertutup rapat. Dari menara, King Dwarf Thrain berteriak:",
        "'Siapa di sana?! Naga es mengamuk sejak langit utara menghitam! Kami tak butuh tamu!'",
        "Orin mengangkat pecahan Mahkota kalian. Gerbang terbuka perlahan.")
    pause()

    say("\nDi aula batu, Thrain berjanggut putih duduk gelisah.",
        "'Seekor naga es purba, Vyrmax, dulu tidur di puncak. Beberapa pekan lalu seorang berjubah hitam",
        "datang membawa kristal ungu, lalu naga itu mengamuk. Dia ingin pecahan di tanganmu.'")
    print("\nBagaimana sikapmu kepada para dwarf?")
    options = ["Bantu mereka tanpa pamrih",
               "Minta imbalan: 100 Gold di muka untuk membantu"]
    if player.gold >= 50:
        options.append("Sumbangkan 50 Gold untuk perbaikan benteng, lalu bantu")
    choice = menu(options)

    if choice == 1:
        player.shift_alignment(10)
        player.flags["thrain_gift"] = True
        say("\nThrain menepuk bahumu keras. 'Kau anak yang lurus! Pandai besiku akan menempa zirah untukmu.'")
    elif choice == 2:
        player.shift_alignment(-10)
        player.gold += 100
        say("\nThrain mendengus dan melempar kantong emas ke mejamu. 'Pedagang... baiklah, tapi jangan harap hadiah.'")
    else:
        player.gold -= 50
        player.shift_alignment(15)
        player.flags["thrain_gift"] = True
        say("\nMata Thrain berkaca-kaca. 'Sudah lama tak ada tamu yang peduli pada kami.'",
            "'Ambil ini, zirah leluhur kami. Anggap hadiah dari para dwarf!'")
    pause()

    if player.flags.get("thrain_gift"):
        if player.armor[1] < 7:
            player.armor = ("Zirah Dwarf", 7)
            print("\nKamu menerima dan memakai Zirah Dwarf (+7 pertahanan)!")
        else:
            player.add_item("Elixir Naga")
            print("\nKarena zirahmu sudah lebih baik, Thrain memberimu Elixir Naga.")

    say("\nThrain membuka peta kulit tua. 'Satu hal lagi. Malachar bukan manusia biasa.",
        "Ia herald Kehampaan, makhluk yang menyamar sebagai penasihat. Raja Arion, ayahmu,",
        "tertidur dalam sihirnya, itulah sebabnya kerajaan membisu.'",
        "\nOrin terpaku. 'Ayahmu... Raja Arion adalah ayahmu. Ratu Seraphine adalah ibumu. Aku... tidak berani berkata.'")
    pause()

    say("\nSaat fajar, kamu mendaki ke sarang naga. Es berderak di bawah kakimu.",
        "Di puncak, pecahan ketiga melayang di tengah jantung kristal, dijaga makhluk raksasa.")
    pause()

    if not story_fight(player, make_vyrmax()):
        return False

    say("\nVyrmax mengerang dan terempas ke salju. Kristal ungu di dadanya retak dan pecah.",
        "'Terima kasih... sudah mencabut... duri itu. Malachar akan menunggu kalian di istana.'",
        "\nCrown Fragment ketiga kamu dapatkan!")
    player.fragments = max(player.fragments, 3)
    player.flags["fragment_3"] = True
    player.shift_alignment(5)
    say("Naga itu terbang ke utara, tak lagi menyerang siapa pun. Para dwarf bersorak.")
    return True


def chapter_4_intro(player):
    player.location = "Istana Eldoria"
    print("\n" + "=" * 52)
    print("  CHAPTER 4: MAHKOTA YANG TERLUPAKAN")
    print("=" * 52)
    print("Menara putih Istana Eldoria menjulang di depanmu. Panji-panji berkibar, tetapi tak ada suara.")


def chapter_4(player):
    say("\nDi gerbang istana, para penjaga menunduk saat kamu lewat. Mereka tidak mengenalimu,",
        "tetapi pecahan di sakumu bersinar. Orin berbisik: 'Mereka bukan lagi manusia. Jangan lama-lama.'",
        "\nDi lorong utama, seorang jenderal berzirah perak menghadang jalanmu.",
        "'Berhenti! Raja tidak menerima tamu. Itu perintah Penasihat Malachar.'")
    pause()

    print("\nApa yang kamu lakukan menghadapi Jenderal Kael?")
    persuade_ok = player.alignment >= 15 or player.flags.get("orin", 0) >= 2
    choice = menu(["Bujuk Kael dengan kebenaran", "Tantang Kael bertarung"])
    fight_kael = True
    enraged = True

    if choice == 1:
        if persuade_ok:
            say("\nKamu menceritakan semuanya: mimpi, Ratu Seraphine, dan sihir yang menyelimuti raja.",
                "Kael lama terdiam. 'Pedangku bersumpah pada raja, bukan pada penasihat. Aku akan berdiri di sisimu.'")
            player.flags["kael_ally"] = True
            player.shift_alignment(10)
            fight_kael = False
        else:
            say("\nKael menggeleng. 'Ucapan semudah itu? Rekam jejakmu tidak meyakinkan. Cabut senjatamu!'")
            enraged = False
    else:
        say("\n'Tak ada waktu untuk bicara,' katamu sambil menghunus senjata.")

    if fight_kael:
        if not story_fight(player, make_kael(enraged)):
            return False
        say("\nKael terduduk, pedangnya terlepas. Sihir ungu keluar dari belakang lehernya seperti asap.",
            "'Apa yang telah aku lakukan...?'")
        print("\nApa yang kamu lakukan?")
        if menu(["Ampuni dia", "Habisi dia"]) == 1:
            player.shift_alignment(8)
            player.flags["kael_ally"] = True
            say("Kael menunduk dalam. 'Hutangku padamu sebesar hidupku.'")
        else:
            player.shift_alignment(-15)
            say("Kamu menebas sekali lagi. Lorong kembali sunyi. Orin membuang muka.")
    pause()

    say("\nPintu besar aula takhta terbuka. Raja Arion duduk kaku, matanya kosong.",
        "Di sampingnya, seorang pria berjubah hitam bertepuk tangan pelan.",
        "'Pewaris Seraphine akhirnya datang membawa pecahan-pecahan itu. Betapa baiknya.'",
        "\nMalachar tersenyum. 'Bergabunglah denganku. Kehampaan bisa memberimu kekuatan yang tak dimiliki",
        "mahkota mana pun. Bersama kita bisa menulis ulang dunia ini.'")
    print("\nBagaimana jawabanmu?")
    choice = menu(["Tolak dengan tegas: 'Keluarkan ayahku dari sihirmu!'",
                   "Berteriak pada Raja Arion agar sadar",
                   "Terima tawaran Malachar (kekuatan Kehampaan)"])

    if choice == 1:
        player.shift_alignment(5)
        say("\n'Betapa naifnya,' Malachar mendesis.")
    elif choice == 2:
        player.shift_alignment(3)
        player.flags["arion_hope"] = True
        say("\nJari raja berkedut. 'Se... ra...' bisiknya. Malachar menggeram dan mencengkeram bahunya.")
    else:
        player.shift_alignment(-25)
        player.flags["void_power"] = True
        player.strength += 6
        player.agility += 6
        player.intelligence += 6
        player.max_health += 40
        player.health = player.max_health
        say("\nMalachar meletakkan serpihan ungu di tanganmu. Kekuatan dingin mengalir ke seluruh tubuhmu!",
            "(STR, AGI, INT +6 dan HP maksimum +40, tapi hatimu menjadi lebih gelap.)",
            "\nMalachar tertawa. 'Terima kasih, bocah. Kini pecahan-pecahan itu... kuambil!'",
            "'Kau pikir aku butuh sekutu? Aku hanya butuh pengantar!'")
    pause()

    if not story_fight(player, make_malachar()):
        return False

    say("\nMalachar menjerit saat tubuhnya terurai menjadi asap ungu, tersedot kembali ke retakan ruang.",
        "Retakan itu menutup dengan raungan sunyi. Raja Arion terhuyung dan sadar.",
        "'Seraphine...? Bukan... kau. Anakku?' Ia memelukmu erat.")
    if player.flags.get("kael_ally"):
        say("Jenderal Kael berlutut, tangannya di dada. 'Eldoria berhutang padamu, Yang Mulia.'")
    pause()

    say("\nKeempat Crown Fragment melayang, berputar, dan menyatu menjadi satu mahkota perak yang bersinar.",
        "Dari dalamnya, suara yang kamu kenal dari mimpi berbisik lembut:",
        "  'Anakku... pilihlah dengan hati-hati. Mahkota ini kini milikmu.'")
    player.fragments = 4
    player.flags["crown_complete"] = True
    print("\nApa yang kamu lakukan dengan Mahkota?")
    final = menu(["Segel Kehampaan dan bebaskan jiwa ibumu",
                  "Ambil seluruh kekuatan Kehampaan untuk dirimu sendiri",
                  "Hancurkan Mahkota selamanya"])
    show_ending(player, final)
    return True


def show_ending(player, final):
    print("\n" + "=" * 52)
    print("  AKHIR CERITA")
    print("=" * 52)

    if final == 1 and player.alignment >= 20:
        print("GOOD ENDING - Fajar Sang Mahkota")
        say("Kamu menempatkan Mahkota di atas altar. Cahaya perak menyelimuti aula. Segel Kehampaan menguat,",
            "dan Ratu Seraphine melangkah keluar dari cahaya, memelukmu setelah seratus tahun.",
            "Eldoria bersatu: manusia, dwarf, dan makhluk hutan bersumpah menjaga perdamaian.")
    elif final == 1:
        print("NEUTRAL ENDING - Harga Sebuah Segel")
        say("Mahkota menutup retakan Kehampaan, tetapi tanganmu terlalu berlumur kegelapan untuk menahan cahayanya.",
            "Sang Ratu hanya muncul sebagai bayangan lembut sebelum menghilang selamanya.",
            "Kamu menghentikan ancaman, tetapi kehilangan banyak hal.")
    elif final == 2:
        print("DARK ENDING - Raja Kehampaan")
        say("Kamu mengangkat Mahkota dan menenggak kekuatan Kehampaan. Mata ungumu menyala.",
            "Raja Arion berlutut bukan karena hormat, melainkan takut. Kamu merebut tahta,",
            "dan membawa kegelapan bagi Eldoria. Di kejauhan, suara Ratu Seraphine menangis.")
    else:
        print("NEUTRAL ENDING - Abu Sang Mahkota")
        say("Kamu menghancurkan Mahkota. Pecahannya menjadi debu perak yang menyegel Kehampaan untuk selamanya.",
            "Jiwa Seraphine akhirnya beristirahat dalam damai. Eldoria diperintah dewan rakyat,",
            "dan namamu dinyanyikan para penyair sebagai penyelamat yang menolak kekuasaan.")

    if player.flags.get("kael_ally"):
        print("Epilog: Jenderal Kael memimpin pasukan kerajaan dengan setia.")
    if player.flags.get("orin", 0) >= 2:
        print("Epilog: Orin pensiun dan mengajar anak-anak desa Aetherwood menempa bilah.")
    elif "orin" in player.flags:
        print("Epilog: Orin menghilang ke utara, sendirian seperti biasa.")
    if player.flags.get("verdanox_saved"):
        print("Epilog: Hutan Eldergloom mekar kembali. Verdanox menjaga gerbangnya.")

    print("\n=== STATUS AKHIR ===")
    player.show_status()
    print("\nTerima kasih telah bermain!")


CHAPTERS = [
    (chapter_1_intro, chapter_1),
    (chapter_2_intro, chapter_2),
    (chapter_3_intro, chapter_3),
    (chapter_4_intro, chapter_4),
]


# ==========================================
# GAME LOOP
# ==========================================

def play(player):
    """Jalankan chapter berurutan. Kembali bila game selesai / pemain keluar."""
    while player.chapter < len(CHAPTERS):
        intro, events = CHAPTERS[player.chapter]
        intro(player)
        hub(player)
        snapshot = player.to_dict()
        save_game(player, quiet=True)

        if events(player):
            player.chapter += 1
            player.health = player.max_health
            player.mana = player.max_mana
            save_game(player, quiet=True)
            continue

        print("\n=== GAME OVER ===")
        print("Mulai ulang dari awal chapter ini dengan kondisi sebelum pertarungan?")
        if menu(["Bangkit dan coba lagi", "Keluar ke menu"]) == 2:
            return
        player.restore(snapshot)
        player.health = player.max_health
        player.mana = player.max_mana


def create_character():
    name = ask("Masukkan nama karakter: ")
    while not name:
        print("Nama karakter tidak boleh kosong.")
        name = ask("Masukkan nama karakter: ")

    print("\nPilih kelas:")
    char_class = CLASSES[menu([
        "Warrior (kuat & tangguh)",
        "Mage (sihir mematikan)",
        "Rogue (lincah & kritikal)",
    ]) - 1]
    return Player(name, char_class)


def start_game():
    print("\nSelamat datang di Echoes of the Forgotten Crown!")
    print("Kamu adalah petualang muda di kerajaan Eldoria.")
    print("Malam ini, seorang ratu kuno memanggil namamu dalam mimpi...")

    player = None
    saved = load_game()
    if saved and saved.chapter < len(CHAPTERS):
        print(f"\nDitemukan save: {saved.name} ({saved.char_class}) Lv.{saved.level}, "
              f"Chapter {saved.chapter + 1}.")
        if menu(["Lanjutkan petualangan", "Mulai game baru (save lama ditimpa)"]) == 1:
            player = saved
    if player is None:
        player = create_character()

    player.show_status()
    play(player)


# ==========================================
# LOGIN / REGISTER MENU
# ==========================================

def _pbkdf2(password, salt, iterations):
    """PBKDF2-SHA256. Memakai hashlib bila ada, jika tidak (build Android tanpa OpenSSL) pakai versi Python murni."""
    if hasattr(hashlib, "pbkdf2_hmac"):
        return hashlib.pbkdf2_hmac("sha256", password, salt, iterations)
    prf = hmac.new(password, digestmod=hashlib.sha256)
    u = prf.copy()
    u.update(salt + b"\x00\x00\x00\x01")
    u = u.digest()
    result = int.from_bytes(u, "big")
    for _ in range(iterations - 1):
        h = prf.copy()
        h.update(u)
        u = h.digest()
        result ^= int.from_bytes(u, "big")
    return result.to_bytes(32, "big")


def hash_password(password, salt=None):
    salt = salt or os.urandom(16).hex()
    digest = _pbkdf2(password.encode("utf-8"), bytes.fromhex(salt), 100_000).hex()
    return f"pbkdf2${salt}${digest}"


def verify_password(stored, password):
    if stored.startswith("pbkdf2$"):
        parts = stored.split("$")
        if len(parts) != 3:
            return False
        try:
            return hmac.compare_digest(hash_password(password, parts[1]), stored)
        except ValueError:
            return False
    # akun lama (plaintext) tetap bisa login, lalu di-upgrade ke hash
    return hmac.compare_digest(stored.encode("utf-8"), password.encode("utf-8"))


def auth_menu():
    """Mengembalikan user_id bila berhasil masuk, atau None bila keluar."""
    while True:
        print("\n=== MENU AKUN ===")
        choice = menu(["Register", "Login", "Lihat Data User", "Keluar"], "Pilih: ")

        if choice == 1:
            username = ask("Username: ")
            password = input("Password: ")

            if not username or not password:
                print("Username dan password tidak boleh kosong!")
                continue

            try:
                cursor.execute(
                    "INSERT INTO users (username, password) VALUES (?, ?)",
                    (username, hash_password(password))
                )
                db.commit()
                print("Register berhasil! Kamu akan masuk ke game.")
                return cursor.lastrowid
            except sqlite3.IntegrityError:
                print("Username sudah digunakan!")
            except sqlite3.Error as error:
                print(f"Terjadi error database: {error}")

        elif choice == 2:
            username = ask("Username: ")
            password = input("Password: ")

            cursor.execute("SELECT id, password FROM users WHERE username = ?", (username,))
            row = cursor.fetchone()

            if row and verify_password(row[1], password):
                if not row[1].startswith("pbkdf2$"):
                    cursor.execute("UPDATE users SET password = ? WHERE id = ?",
                                   (hash_password(password), row[0]))
                    db.commit()
                print("Login berhasil! Kamu akan masuk ke game.")
                return row[0]
            print("Username atau password salah!")

        elif choice == 3:
            cursor.execute("SELECT id, username FROM users ORDER BY id")
            users = cursor.fetchall()

            if users:
                print("\n=== DAFTAR USER ===")
                for user_id, username in users:
                    print(f"ID: {user_id} | Username: {username}")
            else:
                print("Belum ada data pengguna.")

        else:
            print("Program selesai. Sampai jumpa!")
            return None


# ==========================================
# PROGRAM UTAMA
# ==========================================

def run_game():
    """Satu sesi: menu akun, lalu game. Dipanggil oleh CLI maupun UI Android."""
    global CURRENT_USER_ID
    CURRENT_USER_ID = None
    try:
        CURRENT_USER_ID = auth_menu()
        if CURRENT_USER_ID is not None:
            start_game()
    except (KeyboardInterrupt, EOFError):
        print("\nProgram dihentikan. Terima kasih sudah bermain!")


if __name__ == "__main__":
    try:
        run_game()
    finally:
        db.close()
