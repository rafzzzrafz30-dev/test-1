[app]
title = Echoes of the Forgotten Crown
package.name = echoescrown
package.domain = org.echoes
source.dir = .
source.include_exts = py,png,jpg,kv,atlas
source.exclude_dirs = tests,bin,.github,.buildozer
version = 1.0.0
requirements = python3,kivy==2.3.0,sqlite3
orientation = portrait
fullscreen = 0
android.archs = arm64-v8a, armeabi-v7a
android.api = 33
android.minapi = 21
android.accept_sdk_license = True
android.allow_backup = True

[buildozer]
log_level = 2
warn_on_root = 1
