"""Echoes of the Forgotten Crown - antarmuka Android (Kivy).

Logika game ada di game_core.py (kode asli). File ini hanya memasang
tampilan: log cerita di atas, tombol pilihan / kolom input di bawah.
Game berjalan di thread terpisah; tiap menu/input memblokir thread itu
sampai pemain menekan tombol.
"""
import os
import queue
import threading
import traceback

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp, sp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput

MAX_LINES = 600
TEXT = (0.92, 0.92, 0.86, 1)
BTN = (0.20, 0.24, 0.38, 1)
BTN_ACCENT = (0.55, 0.38, 0.12, 1)


class EchoesApp(App):
    title = "Echoes of the Forgotten Crown"

    # ------------------------------------------------------------ UI
    def build(self):
        Window.clearcolor = (0.06, 0.06, 0.09, 1)
        Window.softinput_mode = "below_target"
        self.lines = []
        self.inbox = queue.Queue()
        self.core = None

        root = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(6))

        self.scroll = ScrollView(size_hint=(1, 0.52), bar_width=dp(4))
        self.log = Label(text="", size_hint_y=None, halign="left", valign="top",
                         font_size=sp(15), color=TEXT)
        self.log.bind(
            width=lambda w, v: setattr(w, "text_size", (v, None)),
            texture_size=lambda w, v: setattr(w, "height", v[1] + dp(8)),
        )
        self.scroll.add_widget(self.log)
        root.add_widget(self.scroll)

        self.panel_scroll = ScrollView(size_hint=(1, 0.48), bar_width=dp(4))
        self.box = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(6))
        self.box.bind(minimum_height=self.box.setter("height"))
        self.panel_scroll.add_widget(self.box)
        root.add_widget(self.panel_scroll)
        return root

    def make_button(self, text, on_press, color=BTN):
        btn = Button(text=text, size_hint_y=None, height=dp(48), font_size=sp(15),
                     halign="center", valign="middle", background_normal="",
                     background_color=color)
        btn.bind(width=lambda w, v: setattr(w, "text_size", (v - dp(16), None)),
                 texture_size=lambda w, v: setattr(w, "height", max(dp(48), v[1] + dp(22))))
        btn.bind(on_release=lambda *_: on_press())
        return btn

    def append(self, text):
        self.lines.extend(text.split("\n"))
        if len(self.lines) > MAX_LINES:
            self.lines = self.lines[-MAX_LINES:]
        self.log.text = "\n".join(self.lines)
        Clock.schedule_once(lambda dt: setattr(self.scroll, "scroll_y", 0), 0.05)

    def clear_panel(self):
        self.box.clear_widgets()
        self.panel_scroll.scroll_y = 1

    def answer(self, value, echo=None):
        self.clear_panel()
        if echo:
            self.append("> " + echo)
        self.inbox.put(value)

    def show_menu(self, options, prompt):
        self.clear_panel()
        if prompt and prompt not in ("Pilihan: ",):
            hint = Label(text=prompt.rstrip(": "), size_hint_y=None, height=dp(24),
                         font_size=sp(13), color=(0.7, 0.7, 0.75, 1))
            self.box.add_widget(hint)
        for i, text in enumerate(options, 1):
            self.box.add_widget(self.make_button(
                text, lambda i=i, t=text: self.answer(i, t)))

    def show_pause(self):
        self.clear_panel()
        self.box.add_widget(self.make_button("Lanjut >>", lambda: self.answer(None),
                                             BTN_ACCENT))

    def show_input(self, prompt):
        self.clear_panel()
        secret = "assword" in prompt
        self.box.add_widget(Label(text=prompt.rstrip(": "), size_hint_y=None,
                                  height=dp(28), font_size=sp(14), color=TEXT))
        field = TextInput(multiline=False, password=secret, size_hint_y=None,
                          height=dp(46), font_size=sp(16), write_tab=False)

        def submit(*_):
            self.answer(field.text, "*" * len(field.text) if secret else field.text)

        field.bind(on_text_validate=submit)
        self.box.add_widget(field)
        self.box.add_widget(self.make_button("OK", submit, BTN_ACCENT))
        Clock.schedule_once(lambda dt: setattr(field, "focus", True), 0.1)

    # ------------------------------------------- jembatan thread game
    def _ui(self, fn, *args):
        Clock.schedule_once(lambda dt: fn(*args))

    def w_print(self, text):
        self._ui(self.append, text)

    def w_menu(self, options, prompt=""):
        self._ui(self.show_menu, list(options), prompt)
        return self.inbox.get()

    def w_pause(self):
        self._ui(self.show_pause)
        self.inbox.get()

    def w_input(self, prompt=""):
        self._ui(self.show_input, prompt)
        return self.inbox.get()

    # ---------------------------------------------------- siklus app
    def on_start(self):
        os.environ["ECHOES_DB"] = os.path.join(self.user_data_dir, "database.db")
        import game_core
        self.core = game_core
        game_core.IO.update(print=self.w_print, input=self.w_input,
                            menu=self.w_menu, pause=self.w_pause)
        threading.Thread(target=self.run_loop, daemon=True).start()

    def run_loop(self):
        try:
            while True:
                self.core.run_game()
                self.w_print("\n=== Sesi selesai ===")
                if self.w_menu(["Kembali ke menu awal", "Keluar aplikasi"]) == 2:
                    break
        except Exception:
            self.w_print("\n[ERROR]\n" + traceback.format_exc())
            self.w_menu(["Keluar aplikasi"])
        Clock.schedule_once(lambda dt: self.stop())

    def on_pause(self):
        return True  # jangan matikan app saat ke background

    def on_stop(self):
        try:
            if self.core:
                self.core.db.commit()
                self.core.db.close()
        except Exception:
            pass


if __name__ == "__main__":
    EchoesApp().run()
