# Echoes of the Forgotten Crown (Android)

RPG teks Eldoria, dibungkus dengan antarmuka Kivy. Akun dan save game tersimpan
di penyimpanan privat aplikasi (SQLite).

## Cara membuat APK (paling mudah: GitHub Actions)
1. Buat repository baru di GitHub, lalu upload semua isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** > workflow **Build APK** (jalan otomatis saat upload, atau klik *Run workflow*).
3. Tunggu 15-30 menit (build pertama lama), lalu unduh artifact **echoes-apk**, ekstrak, dan pasang `.apk` di HP
   (aktifkan "Install dari sumber tidak dikenal").

## Cara lain: build sendiri (Linux / WSL Ubuntu)
    pip install buildozer cython
    sudo apt install -y git zip unzip openjdk-17-jdk autoconf libtool pkg-config zlib1g-dev libncurses5-dev libffi-dev libssl-dev
    buildozer android debug      # hasil: bin/*.apk

## Coba di komputer
    pip install kivy
    python main.py               # versi GUI
    python game_core.py          # versi terminal asli

## Struktur
- `game_core.py` : kode game asli (hanya ditambah hook input/output)
- `main.py`      : UI Kivy (log cerita, tombol pilihan, kolom input)
- `buildozer.spec`, `.github/workflows/build-apk.yml` : konfigurasi build
